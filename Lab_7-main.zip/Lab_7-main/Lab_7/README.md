# Lab_07
![image](https://user-images.githubusercontent.com/86685162/165841302-aed6d035-ac51-4659-9a6e-9af36d9fa787.png)


Ele Calcula o troco e mostra como seria o troco em moedas diferentes
