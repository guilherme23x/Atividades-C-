# lab_004
![image](https://user-images.githubusercontent.com/86685162/165831048-fc099515-df81-4739-811a-5b46b1980870.png)


Este Software faz o Calculo do número vezes ele mesmo

