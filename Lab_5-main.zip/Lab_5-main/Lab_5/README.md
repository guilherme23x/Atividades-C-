# Lab_04
![image](https://user-images.githubusercontent.com/86685162/164085862-7303a59e-3986-4817-a33f-110d81e3b1c4.png)




pode Buscar até 3 Imagens
