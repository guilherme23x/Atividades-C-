﻿
namespace Lab_11.View
{
    partial class Telaprincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Telaprincipal));
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblKM = new System.Windows.Forms.Label();
            this.lblLitros = new System.Windows.Forms.Label();
            this.lblRendimento = new System.Windows.Forms.Label();
            this.lblCosumo = new System.Windows.Forms.Label();
            this.tbxKM = new System.Windows.Forms.TextBox();
            this.tbxLitros = new System.Windows.Forms.TextBox();
            this.lblRendimentoResultado = new System.Windows.Forms.Label();
            this.lblConsumoResultado = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCacular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.Transparent;
            this.lblTitulo.Font = new System.Drawing.Font("Swis721 BlkEx BT", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(56, 22);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(325, 22);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Calculo de Combustível";
            // 
            // lblKM
            // 
            this.lblKM.AutoSize = true;
            this.lblKM.BackColor = System.Drawing.Color.Transparent;
            this.lblKM.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblKM.Location = new System.Drawing.Point(73, 71);
            this.lblKM.Name = "lblKM";
            this.lblKM.Size = new System.Drawing.Size(38, 21);
            this.lblKM.TabIndex = 1;
            this.lblKM.Text = "&KM:";
            // 
            // lblLitros
            // 
            this.lblLitros.AutoSize = true;
            this.lblLitros.BackColor = System.Drawing.Color.Transparent;
            this.lblLitros.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblLitros.Location = new System.Drawing.Point(73, 110);
            this.lblLitros.Name = "lblLitros";
            this.lblLitros.Size = new System.Drawing.Size(51, 21);
            this.lblLitros.TabIndex = 2;
            this.lblLitros.Text = "Litros";
            // 
            // lblRendimento
            // 
            this.lblRendimento.AutoSize = true;
            this.lblRendimento.BackColor = System.Drawing.Color.Transparent;
            this.lblRendimento.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblRendimento.Location = new System.Drawing.Point(132, 154);
            this.lblRendimento.Name = "lblRendimento";
            this.lblRendimento.Size = new System.Drawing.Size(180, 21);
            this.lblRendimento.TabIndex = 3;
            this.lblRendimento.Text = "Rendimentos KM/Litros";
            // 
            // lblCosumo
            // 
            this.lblCosumo.AutoSize = true;
            this.lblCosumo.BackColor = System.Drawing.Color.Transparent;
            this.lblCosumo.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblCosumo.Location = new System.Drawing.Point(143, 285);
            this.lblCosumo.Name = "lblCosumo";
            this.lblCosumo.Size = new System.Drawing.Size(156, 21);
            this.lblCosumo.TabIndex = 4;
            this.lblCosumo.Text = "Consumo - Litro/KM";
            // 
            // tbxKM
            // 
            this.tbxKM.Location = new System.Drawing.Point(143, 71);
            this.tbxKM.Name = "tbxKM";
            this.tbxKM.Size = new System.Drawing.Size(169, 23);
            this.tbxKM.TabIndex = 5;
            // 
            // tbxLitros
            // 
            this.tbxLitros.Location = new System.Drawing.Point(143, 110);
            this.tbxLitros.Name = "tbxLitros";
            this.tbxLitros.Size = new System.Drawing.Size(169, 23);
            this.tbxLitros.TabIndex = 6;
            // 
            // lblRendimentoResultado
            // 
            this.lblRendimentoResultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblRendimentoResultado.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblRendimentoResultado.Location = new System.Drawing.Point(104, 191);
            this.lblRendimentoResultado.Name = "lblRendimentoResultado";
            this.lblRendimentoResultado.Size = new System.Drawing.Size(228, 76);
            this.lblRendimentoResultado.TabIndex = 7;
            this.lblRendimentoResultado.Tag = "1";
            this.lblRendimentoResultado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblConsumoResultado
            // 
            this.lblConsumoResultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblConsumoResultado.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblConsumoResultado.Location = new System.Drawing.Point(104, 325);
            this.lblConsumoResultado.Name = "lblConsumoResultado";
            this.lblConsumoResultado.Size = new System.Drawing.Size(228, 86);
            this.lblConsumoResultado.TabIndex = 8;
            this.lblConsumoResultado.Tag = "1";
            this.lblConsumoResultado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 50);
            this.label1.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(386, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 50);
            this.label2.TabIndex = 9;
            // 
            // btnCacular
            // 
            this.btnCacular.BackColor = System.Drawing.Color.Red;
            this.btnCacular.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCacular.Location = new System.Drawing.Point(167, 436);
            this.btnCacular.Name = "btnCacular";
            this.btnCacular.Size = new System.Drawing.Size(97, 44);
            this.btnCacular.TabIndex = 10;
            this.btnCacular.Text = "Calcular";
            this.btnCacular.UseVisualStyleBackColor = false;
            this.btnCacular.Click += new System.EventHandler(this.btnCacular_Click);
            // 
            // Telaprincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(427, 524);
            this.Controls.Add(this.btnCacular);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblConsumoResultado);
            this.Controls.Add(this.lblRendimentoResultado);
            this.Controls.Add(this.tbxLitros);
            this.Controls.Add(this.tbxKM);
            this.Controls.Add(this.lblCosumo);
            this.Controls.Add(this.lblRendimento);
            this.Controls.Add(this.lblLitros);
            this.Controls.Add(this.lblKM);
            this.Controls.Add(this.lblTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "Telaprincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema de Consumo de Combustível";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Telaprincipal_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblKM;
        private System.Windows.Forms.Label lblLitros;
        private System.Windows.Forms.Label lblRendimento;
        private System.Windows.Forms.Label lblCosumo;
        private System.Windows.Forms.TextBox tbxKM;
        private System.Windows.Forms.TextBox tbxLitros;
        private System.Windows.Forms.Label lblRendimentoResultado;
        private System.Windows.Forms.Label lblConsumoResultado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCacular;
    }
}