# Lab_06
![Capturar](https://user-images.githubusercontent.com/86685162/165377749-981d2506-340e-478b-84cd-4a56f185a7e3.PNG)


Esse é uma cópia Limitada do Bloco de Notas
