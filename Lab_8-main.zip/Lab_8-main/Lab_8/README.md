# lab_8
  ![image](https://user-images.githubusercontent.com/86685162/166980590-a109e8ae-bdae-42b5-bee5-3d93eee5dd7b.png)
![image](https://user-images.githubusercontent.com/86685162/166559863-4e2806c8-b328-493d-b6cd-723038b48f8b.png)






no Pimeiro mostra o maior número e o Segundo programa mostra o calculo em Frete de uma compra por exemplo
