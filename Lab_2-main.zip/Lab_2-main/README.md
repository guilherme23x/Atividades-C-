# lab_02
![image](https://user-images.githubusercontent.com/86685162/164066134-eb105103-ea68-460b-81d4-3169637a3ff8.png)


Tem que Aparecer as cores de acordo com o barramento
